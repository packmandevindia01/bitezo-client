var e=(e,t,n=!1)=>{let r=parseInt(localStorage.getItem(`decimalPart`)||`3`,10),i=e=>Number(e||0).toFixed(r),a=e=>{if(!e||e.includes(`1900-01-01`))return``;try{return new Date(e).toLocaleDateString(`en-GB`)}catch{return``}},o=e=>{if(!e||e.includes(`1900-01-01`))return``;try{return new Date(e).toLocaleTimeString(`en-US`,{hour:`numeric`,minute:`2-digit`,second:`2-digit`,hour12:!0})}catch{return``}},s=e.header||{},c=e.generalSummary||{},l=e.cashFlow||{},u=e=>!e||e.toLowerCase()===`string`?``:`<div>${e}</div>`,d=`
    <div class="text-center font-bold">
      <div style="font-size: 18px;">${s.dayEndHeader1&&s.dayEndHeader1.toLowerCase()!==`string`?s.dayEndHeader1:``}</div>
      ${u(s.dayEndHeader2)}
      ${u(s.dayEndHeader3)}
      ${u(s.dayEndHeader4)}
      ${u(s.dayEndHeader5)}
      ${u(s.dayEndHeader6)}
      <div style="font-size: 16px; margin-top: 10px; font-weight: bold; text-transform: uppercase;">
        ${t===`DAYEND`?`DAYEND REPORT`:`SHIFTEND REPORT`}
      </div>
    </div>
  `,f=`
    <table style="width: 100%; margin-top: 10px;">
      <tbody>
        <tr><td style="width: 40%;">Start Date</td><td>: ${a(c.startDate)}</td></tr>
        <tr><td>Start Time</td><td>: ${o(c.startDate)}</td></tr>
        <tr><td>End Date</td><td>: ${a(c.endDate)}</td></tr>
        <tr><td>End Time</td><td>: ${o(c.endDate)}</td></tr>
      </tbody>
    </table>
    <hr />
  `,p=`
    <div class="section-title">Order Summary</div>
    <table class="data-table mb-10">
      <tbody>
  `,m=0;(e.orderTypes||[]).forEach(e=>{m+=e.total,p+=`
      <tr>
        <td colspan="2" class="font-bold">${e.orderType}</td>
        <td class="font-bold text-center">Count : ${e.count||0}</td>
        <td colspan="2" class="text-right font-bold">Total : ${i(e.total)}</td>
      </tr>
    `}),p+=`
      <tr>
        <td colspan="3"></td>
        <td colspan="2" class="text-right font-bold">Total : ${i(m)}</td>
      </tr>
  </tbody></table><hr />`;let h=`
    <table class="data-table mb-10">
      <tbody>
        <tr><td colspan="2" class="font-bold">Waiter Summary</td><td class="text-right">X</td></tr>
  `;(e.waiters||[]).forEach(e=>{h+=`<tr><td>${e.waiter}</td><td class="text-right">${i(e.total)}</td></tr>`}),h+=`
        <tr><td class="font-bold">Total</td><td class="text-right font-bold">${i(e.waiters?.reduce((e,t)=>e+t.total,0))}</td></tr>
      </tbody>
    </table><hr />
  `;let g=`
    <div class="section-title">Sales By Category</div>
    <table class="data-table mb-10">
      <thead>
        <tr>
          <th>Category</th>
          <th>Qty</th>
          <th class="text-right">Net</th>
        </tr>
      </thead>
      <tbody>
  `;(e.categories||[]).forEach(e=>{g+=`
        <tr>
          <td>${e.categoryName}</td>
          <td>${e.qty}</td>
          <td class="text-right">${i(e.total)}</td>
        </tr>
    `}),g+=`</tbody></table><hr />`;let _=``;if(e.voidProducts&&e.voidProducts.length>0){_=`
      <div class="section-title">Void Items</div>
      <table class="data-table mb-10">
        <thead>
          <tr>
            <th>Product</th>
            <th>BillNo</th>
            <th>Waiter</th>
            <th>Time</th>
            <th>Qty</th>
            <th class="text-right">Amt</th>
          </tr>
        </thead>
        <tbody>
    `;let t=0;e.voidProducts.forEach(e=>{let n=e.amount||0;t+=n,_+=`
          <tr>
            <td>${e.productName||e.product}</td>
            <td>${e.billNo}</td>
            <td>${e.waiter}</td>
            <td>${o(e.time)}</td>
            <td>${e.qty}</td>
            <td class="text-right">${i(n)}</td>
          </tr>
      `}),_+=`
          <tr><td colspan="5" class="text-right font-bold">Total</td><td class="text-right font-bold">${i(t)}</td></tr>
        </tbody>
      </table><hr />
    `}let v=`
    <div class="section-title">Payment Summary</div>
    <table class="data-table mb-10">
      <thead>
        <tr>
          <th>Paymode</th>
          <th class="text-right">Amount</th>
        </tr>
      </thead>
      <tbody>
  `,y=0;(e.paymodes||[]).forEach(e=>{y+=e.amount,v+=`<tr><td>${e.paymodeName}</td><td class="text-right">${i(e.amount)}</td></tr>`}),v+=`
        <tr><td class="font-bold">Total</td><td class="text-right font-bold">${i(y)}</td></tr>
      </tbody>
    </table><hr />
  `;let b=`
    <div class="section-title">Tax Summary</div>
    <table class="data-table mb-10">
      <thead>
        <tr>
          <th>Rate</th>
          <th>Amount</th>
          <th class="text-right">VAT Amount</th>
        </tr>
      </thead>
      <tbody>
  `,x=0;(e.taxSummary||[]).forEach(e=>{x+=e.vatAmount,b+=`<tr><td>${e.vatName}</td><td>${i(e.exclAmount)}</td><td class="text-right">${i(e.vatAmount)}</td></tr>`}),b+=`
        <tr><td colspan="2"></td><td class="text-right font-bold">${i(x)}</td></tr>
      </tbody>
    </table><hr />
  `;let S=`
    <table class="data-table mb-10">
      <tbody>
        <tr><td>Sale</td><td class="text-right">${i(e.salesSummary?.sales)}</td></tr>
        <tr><td>Delivery Charge</td><td class="text-right">${i(e.salesSummary?.deliveryCharge)}</td></tr>
        <tr><td>VAT Amount</td><td class="text-right">${i(e.salesSummary?.vatAmount)}</td></tr>
        <tr><td class="font-bold">Grand Total</td><td class="text-right font-bold">${i((e.salesSummary?.sales||0)+x+(e.salesSummary?.deliveryCharge||0))}</td></tr>
        <tr><td>Cancelled Sales</td><td class="text-right">${i(c.voidSales)}</td></tr>
        <tr><td>Cancelled Order</td><td class="text-right">${i(c.voidOrders)}</td></tr>
      </tbody>
    </table><hr />
  `,C=`
    <table class="data-table mb-10">
      <tbody>
        <tr><td>Pending Order</td><td class="text-right">${i(c.pendingOrder)}</td></tr>
      </tbody>
    </table><hr style="border-top: 1px dashed #000;" />
    <table class="data-table">
      <tbody>
        <tr><td class="font-bold">Cash Flow</td><td class="text-right font-bold">X</td></tr>
        <tr><td>CASH</td><td class="text-right">${i(l.cashSales)}</td></tr>
        <tr><td>Pay In</td><td class="text-right">${i(l.payIn)}</td></tr>
        <tr><td class="font-bold">Total Cash In</td><td class="text-right font-bold">${i((l.cashSales||0)+(l.payIn||0))}</td></tr>
        <tr><td>Pay Out</td><td class="text-right">${i(l.payOut)}</td></tr>
        <tr><td class="font-bold">Total Cash Out</td><td class="text-right font-bold">${i(l.payOut)}</td></tr>
        <tr><td>Net Cash</td><td class="text-right">${i((l.cashSales||0)+(l.payIn||0)-(l.payOut||0))}</td></tr>
        <tr><td class="font-bold">Closing Balance</td><td class="text-right font-bold">${i(l.closingBal)}</td></tr>
        <tr><td class="font-bold">Difference</td><td class="text-right font-bold">${i(l.closingBal-(l.cashSales+l.payIn-l.payOut))}</td></tr>
      </tbody>
    </table><hr />
  `;return`
    <html>
      <head>
        <style>
          ${n?`
          @page { size: A4 portrait; margin: 15mm; }
          body { width: 210mm; max-width: 100%; margin: 0 auto; }
          `:`
          body { width: 100%; margin: 0; }
          `}
          * {
            border-color: #000000 !important;
            outline-color: transparent !important;
            background-color: transparent !important;
          }
          html, body {
            background-color: #ffffff !important;
          }
          body {
            font-family: Arial, Helvetica, sans-serif;
            font-size: 13px;
            color: #000;
            padding: 0;
          }
          .text-center { text-align: center; }
          .text-right { text-align: right; }
          .font-bold { font-weight: bold; }
          .section-title { font-weight: bold; margin: 10px 0 5px 0; }
          .mb-10 { margin-bottom: 10px; }
          
          table { width: 100%; font-size: 12px; border-collapse: collapse; }
          th { text-align: left; font-weight: bold; border-bottom: 1px dashed #000; padding-bottom: 3px; }
          td { padding: 2px 0; vertical-align: top; }
          
          hr { border: none; border-top: 1px solid #000; margin: 8px 0; }
        </style>
      </head>
      <body>
        ${d}
        ${f}
        ${p}
        ${h}
        ${g}
        ${_}
        ${v}
        ${b}
        ${S}
        ${C}
      </body>
    </html>
  `};export{e as t};