import{i as e}from"./rolldown-runtime-B1FJdls4.js";import{_ as t}from"./vendor-charts-C2P2TtIT.js";import{Mn as n,_t as r,k as i,tn as a}from"./vendor-react-HlPeU5X5.js";import{o}from"./ResetButton-UI_PtTYY.js";import{t as s}from"./axiosInstance-B2aOK9w-.js";import{t as c}from"./formatters-BlFhPG4_.js";import{t as l}from"./useToast-BWogByx7.js";import{n as u}from"./companyApi-Cvu06Rtn.js";import{t as d}from"./numberToWords-Cz42_MtA.js";var f=e(t(),1),p=n(),m={BHD:`BAHRAINI DINAR`,USD:`US DOLLAR`,EUR:`EURO`,GBP:`POUND STERLING`,AED:`UAE DIRHAM`,SAR:`SAUDI RIYAL`,QAR:`QATARI RIYAL`,KWD:`KUWAITI DINAR`,OMR:`OMANI RIAL`,INR:`INDIAN RUPEE`},h={BHD:`FILS`,KWD:`FILS`,OMR:`BAISA`,USD:`CENTS`,EUR:`CENTS`,GBP:`PENCE`,AED:`FILS`,SAR:`HALALAH`,QAR:`DIRHAM`,INR:`PAISE`},g=(0,f.forwardRef)(({data:e,templateVariant:t},n)=>{let r=t===`With Tax`,i=e.docTitle.toLowerCase().includes(`return`),a=localStorage.getItem(`currencySymbol`)||`BHD`,o=parseInt(localStorage.getItem(`decimalPart`)||`3`,10),s=m[a]||a,l=h[a]||`FILS`,u=e.items.reduce((e,t)=>e+(t.amount||0),0),f=e.items.reduce((e,t)=>e+((t.amount||0)-(t.netValue||0)),0),g=e.items.reduce((e,t)=>e+(t.netValue||0),0),_=e.items.reduce((e,t)=>e+(t.vatAmt||0),0),v=e.items.reduce((e,t)=>e+(t.netAmount||0),0);return(0,p.jsxs)(`div`,{id:`print-template`,ref:n,className:`p-8 font-sans`,style:{width:`210mm`,minHeight:`297mm`,margin:`0 auto`,fontSize:`12px`,backgroundColor:`#ffffff`,color:`#000000`},children:[(0,p.jsx)(`style`,{children:`
            #print-template * {
              border-color: #000000 !important;
              color: inherit;
              outline-color: #000000 !important;
              background-color: transparent !important;
              box-shadow: none !important;
              text-shadow: none !important;
              --tw-border-spacing-x: 0;
              --tw-border-spacing-y: 0;
              --tw-translate-x: 0;
              --tw-translate-y: 0;
              --tw-rotate: 0;
              --tw-skew-x: 0;
              --tw-skew-y: 0;
              --tw-scale-x: 1;
              --tw-scale-y: 1;
              --tw-pan-x: ;
              --tw-pan-y: ;
              --tw-pinch-zoom: ;
              --tw-scroll-snap-strictness: proximity;
              --tw-ordinal: ;
              --tw-slashed-zero: ;
              --tw-numeric-figure: ;
              --tw-numeric-spacing: ;
              --tw-numeric-fraction: ;
              --tw-ring-inset: ;
              --tw-ring-offset-width: 0px;
              --tw-ring-offset-color: #fff;
              --tw-ring-color: #000000;
              --tw-ring-offset-shadow: 0 0 #0000;
              --tw-ring-shadow: 0 0 #0000;
              --tw-shadow: 0 0 #0000;
              --tw-shadow-colored: 0 0 #0000;
              --tw-blur: ;
              --tw-brightness: ;
              --tw-contrast: ;
              --tw-grayscale: ;
              --tw-hue-rotate: ;
              --tw-invert: ;
              --tw-saturate: ;
              --tw-sepia: ;
              --tw-drop-shadow: ;
              --tw-backdrop-blur: ;
              --tw-backdrop-brightness: ;
              --tw-backdrop-contrast: ;
              --tw-backdrop-grayscale: ;
              --tw-backdrop-hue-rotate: ;
              --tw-backdrop-invert: ;
              --tw-backdrop-opacity: ;
              --tw-backdrop-saturate: ;
              --tw-backdrop-sepia: ;
            }
            #print-template table, #print-template th, #print-template td {
              border-color: #000000 !important;
            }
          `}),(0,p.jsxs)(`div`,{className:`text-center font-bold mb-4`,children:[(0,p.jsx)(`h1`,{className:`text-xl`,children:e.companyName}),e.companyAddress.split(`,`).map((e,t)=>(0,p.jsx)(`div`,{className:`text-sm font-normal`,children:e.trim()},t)),(0,p.jsxs)(`div`,{className:`text-sm font-bold mt-1`,children:[`TRN No : `,e.companyTrn]})]}),(0,p.jsx)(`div`,{className:`text-center font-bold text-lg border-y border-[#000000] py-1 mb-4 uppercase`,children:e.docTitle}),(0,p.jsxs)(`div`,{className:`flex justify-between mb-4 text-xs font-bold leading-relaxed`,children:[(0,p.jsxs)(`div`,{className:`flex-1`,children:[(0,p.jsxs)(`div`,{className:`flex`,children:[(0,p.jsx)(`span`,{className:`w-20`,children:`Supplier`}),`: `,e.supplierName]}),(0,p.jsxs)(`div`,{className:`flex`,children:[(0,p.jsx)(`span`,{className:`w-20`,children:`Address`}),`: `,e.supplierAddress]}),(0,p.jsxs)(`div`,{className:`flex`,children:[(0,p.jsx)(`span`,{className:`w-20`,children:`TRN No`}),`: `,e.supplierTrn]})]}),(0,p.jsxs)(`div`,{className:`w-64`,children:[(0,p.jsxs)(`div`,{className:`flex`,children:[(0,p.jsx)(`span`,{className:`w-24`,children:i?`PRT No.`:`Voucher No`}),`: `,e.voucherNo]}),(0,p.jsxs)(`div`,{className:`flex`,children:[(0,p.jsx)(`span`,{className:`w-24`,children:i?`Inv No`:`Purchase No`}),`: `,e.purchaseNo]}),(0,p.jsxs)(`div`,{className:`flex`,children:[(0,p.jsx)(`span`,{className:`w-24`,children:i?`PRT Dt`:`Date`}),`: `,e.date]}),!i&&(0,p.jsxs)(`div`,{className:`flex`,children:[(0,p.jsx)(`span`,{className:`w-24`,children:`Paymode`}),`: `,e.paymode]})]})]}),(0,p.jsx)(`div`,{className:`mb-4`,children:(0,p.jsxs)(`table`,{className:`w-full border-collapse border border-[#000000] text-xs text-center`,children:[(0,p.jsx)(`thead`,{children:(0,p.jsxs)(`tr`,{className:`font-bold border-b border-[#000000]`,children:[(0,p.jsx)(`th`,{className:`border-r border-[#000000] p-1`,children:i?`S/N`:`No.`}),(0,p.jsx)(`th`,{className:`border-r border-[#000000] p-1`,children:i?`Description/Barcode`:`Product`}),(0,p.jsx)(`th`,{className:`border-r border-[#000000] p-1`,children:`Qty`}),i&&(0,p.jsx)(`th`,{className:`border-r border-[#000000] p-1`,children:`Unit`}),(0,p.jsx)(`th`,{className:`border-r border-[#000000] p-1`,children:`FOC`}),!i&&(0,p.jsx)(`th`,{className:`border-r border-[#000000] p-1`,children:`Unit`}),(0,p.jsx)(`th`,{className:`border-r border-[#000000] p-1`,children:`Price`}),!i&&(0,p.jsx)(`th`,{className:`border-r border-[#000000] p-1`,children:`Discount`}),i&&(0,p.jsx)(`th`,{className:`border-r border-[#000000] p-1`,children:`Amount`}),i&&(0,p.jsx)(`th`,{className:`border-r border-[#000000] p-1`,children:`Dis Amt`}),(0,p.jsx)(`th`,{className:`border-r border-[#000000] p-1`,children:i?`Taxable Amount`:`Net Value`}),r&&(0,p.jsx)(`th`,{className:`border-r border-[#000000] p-1`,children:i?`VAT 5%`:`VAT (%)`}),r&&!i&&(0,p.jsx)(`th`,{className:`border-r border-[#000000] p-1`,children:`VAT Amt`}),(0,p.jsx)(`th`,{className:`p-1`,children:`Net Amount`})]})}),(0,p.jsxs)(`tbody`,{children:[e.items.map((e,t)=>(0,p.jsxs)(`tr`,{className:`border-b border-[#000000]`,children:[(0,p.jsx)(`td`,{className:`border-r border-[#000000] p-1 align-top`,children:t+1}),(0,p.jsx)(`td`,{className:`border-r border-[#000000] p-1 align-top text-left`,children:e.productName}),(0,p.jsx)(`td`,{className:`border-r border-[#000000] p-1 align-top`,children:e.qty}),i&&(0,p.jsx)(`td`,{className:`border-r border-[#000000] p-1 align-top`,children:e.unit}),(0,p.jsx)(`td`,{className:`border-r border-[#000000] p-1 align-top`,children:c(e.foc)}),!i&&(0,p.jsx)(`td`,{className:`border-r border-[#000000] p-1 align-top`,children:e.unit}),(0,p.jsx)(`td`,{className:`border-r border-[#000000] p-1 align-top`,children:c(e.price)}),!i&&(0,p.jsx)(`td`,{className:`border-r border-[#000000] p-1 align-top`,children:c(e.discount)}),i&&(0,p.jsx)(`td`,{className:`border-r border-[#000000] p-1 align-top`,children:c(e.amount)}),i&&(0,p.jsx)(`td`,{className:`border-r border-[#000000] p-1 align-top`,children:c(e.discount)}),(0,p.jsx)(`td`,{className:`border-r border-[#000000] p-1 align-top`,children:c(e.netValue)}),r&&(0,p.jsx)(`td`,{className:`border-r border-[#000000] p-1 align-top`,children:i?c(e.vatAmt):`${c(e.vatPercent)}%`}),r&&!i&&(0,p.jsx)(`td`,{className:`border-r border-[#000000] p-1 align-top`,children:c(e.vatAmt)}),(0,p.jsx)(`td`,{className:`p-1 align-top`,children:c(e.netAmount)})]},t)),(0,p.jsxs)(`tr`,{className:`font-bold border-t border-[#000000]`,children:[(0,p.jsx)(`td`,{colSpan:6,className:`text-right p-1`,children:`Total`}),i?(0,p.jsxs)(p.Fragment,{children:[(0,p.jsx)(`td`,{className:`border-l border-[#000000] p-1`,children:c(u)}),(0,p.jsx)(`td`,{className:`border-l border-[#000000] p-1`,children:c(f)}),(0,p.jsx)(`td`,{className:`border-l border-[#000000] p-1`,children:c(g)}),r&&(0,p.jsx)(`td`,{className:`border-l border-[#000000] p-1`,children:c(_)}),(0,p.jsx)(`td`,{className:`border-l border-[#000000] p-1`,children:c(v)})]}):(0,p.jsxs)(p.Fragment,{children:[(0,p.jsx)(`td`,{className:`border-l border-[#000000] p-1`,children:c(f)}),(0,p.jsx)(`td`,{className:`border-l border-[#000000] p-1`,children:c(g)}),r&&(0,p.jsxs)(p.Fragment,{children:[(0,p.jsx)(`td`,{className:`border-l border-[#000000] p-1`}),(0,p.jsx)(`td`,{className:`border-l border-[#000000] p-1`,children:c(_)})]}),(0,p.jsx)(`td`,{className:`border-l border-[#000000] p-1`,children:c(v)})]})]})]})]})}),(0,p.jsxs)(`div`,{className:`flex justify-between items-start text-xs font-bold leading-loose`,children:[(0,p.jsxs)(`div`,{className:`flex-1 pr-4`,children:[(0,p.jsxs)(`div`,{className:`mb-2 flex items-center`,children:[(0,p.jsxs)(`span`,{className:`mr-2`,children:[i?`Amount In Words`:`Grand Total in words`,`:`]}),(0,p.jsx)(`span`,{className:`font-normal`,children:d(e.totals.grandTotal,s,l,o)})]}),r&&e.taxSummary.length>0&&(0,p.jsxs)(`table`,{className:`border-collapse border border-[#000000] text-center mt-2 w-3/4`,children:[(0,p.jsx)(`thead`,{children:(0,p.jsxs)(`tr`,{className:`border-b border-[#000000]`,children:[(0,p.jsx)(`th`,{className:`border-r border-[#000000] p-1`,children:`Tax code`}),(0,p.jsx)(`th`,{className:`border-r border-[#000000] p-1`,children:i?`Taxable`:`Net Value`}),(0,p.jsx)(`th`,{className:`border-r border-[#000000] p-1`,children:i?`VAT Amount`:`Vat Amount`}),(0,p.jsx)(`th`,{className:`p-1`,children:`Net Amount`})]})}),(0,p.jsx)(`tbody`,{className:`font-normal`,children:e.taxSummary.map((e,t)=>(0,p.jsxs)(`tr`,{className:`border-b border-[#000000]`,children:[(0,p.jsx)(`td`,{className:`border-r border-[#000000] p-1`,children:e.taxCode}),(0,p.jsx)(`td`,{className:`border-r border-[#000000] p-1`,children:c(e.taxable)}),(0,p.jsx)(`td`,{className:`border-r border-[#000000] p-1`,children:c(e.vatAmount)}),(0,p.jsx)(`td`,{className:`p-1`,children:c(e.netAmount)})]},t))})]}),i&&(0,p.jsxs)(`div`,{className:`flex justify-between mt-12 font-bold w-full`,children:[(0,p.jsxs)(`div`,{className:`w-1/2`,children:[(0,p.jsx)(`div`,{className:`mb-4`,children:`For : VENDOR`}),(0,p.jsx)(`div`,{children:`SIGNATURE _______________________`})]}),(0,p.jsxs)(`div`,{className:`w-1/2 pl-8`,children:[(0,p.jsxs)(`div`,{className:`mb-4`,children:[`For : `,e.companyName]}),(0,p.jsx)(`div`,{children:`SIGNATURE _______________________`})]})]})]}),(0,p.jsxs)(`div`,{className:`w-64`,children:[(0,p.jsxs)(`div`,{className:`flex justify-between`,children:[(0,p.jsx)(`span`,{className:`w-32`,children:i?`Total Amount`:`Total`}),` `,(0,p.jsx)(`span`,{children:c(e.totals.total)})]}),(0,p.jsxs)(`div`,{className:`flex justify-between`,children:[(0,p.jsx)(`span`,{className:`w-32`,children:`Discount`}),` `,(0,p.jsx)(`span`,{children:c(e.totals.discount)})]}),(0,p.jsxs)(`div`,{className:`flex justify-between`,children:[(0,p.jsx)(`span`,{className:`w-32`,children:`Net Value`}),` `,(0,p.jsx)(`span`,{children:c(e.totals.total-e.totals.discount)})]}),r&&(0,p.jsxs)(`div`,{className:`flex justify-between`,children:[(0,p.jsx)(`span`,{className:`w-32`,children:`VAT`}),` `,(0,p.jsx)(`span`,{children:c(e.totals.vat)})]}),!i&&(0,p.jsxs)(p.Fragment,{children:[(0,p.jsxs)(`div`,{className:`flex justify-between`,children:[(0,p.jsx)(`span`,{className:`w-32`,children:`Adjustment Amount`}),` `,(0,p.jsx)(`span`,{children:c(e.totals.adjustmentAmount)})]}),(0,p.jsxs)(`div`,{className:`flex justify-between`,children:[(0,p.jsx)(`span`,{className:`w-32`,children:`Round Off`}),` `,(0,p.jsx)(`span`,{children:c(e.totals.roundOff)})]})]}),(0,p.jsxs)(`div`,{className:`flex justify-between border-t border-[#000000] mt-1 pt-1`,children:[(0,p.jsx)(`span`,{className:`w-32`,children:i?`Net Amount`:`Grand Total`}),` `,(0,p.jsx)(`span`,{children:c(e.totals.grandTotal)})]})]})]}),!i&&(0,p.jsx)(`div`,{className:`text-right font-bold mt-12 pt-12 pr-8 text-xs`,children:`Authority Signatory`})]})}),_=`
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body { background: #ffffff; font-family: Arial, Helvetica, sans-serif; font-size: 12px; color: #000000; }
  .p-8 { padding: 2rem; }
  .font-sans { font-family: Arial, Helvetica, sans-serif; }
  .text-center { text-align: center; }
  .font-bold { font-weight: bold; }
  .font-normal { font-weight: normal; }
  .font-semibold { font-weight: 600; }
  .text-lg { font-size: 1.125rem; line-height: 1.75rem; }
  .text-xl { font-size: 1.25rem; line-height: 1.75rem; }
  .text-sm { font-size: 0.875rem; }
  .text-xs { font-size: 0.75rem; }
  .border-y { border-top: 1px solid #000000; border-bottom: 1px solid #000000; }
  .border-t { border-top: 1px solid #000000; }
  .border-b { border-bottom: 1px solid #000000; }
  .border-l { border-left: 1px solid #000000; }
  .border-r { border-right: 1px solid #000000; }
  .border { border: 1px solid #000000; }
  .border-collapse { border-collapse: collapse; }
  .py-1 { padding-top: 0.25rem; padding-bottom: 0.25rem; }
  .p-1 { padding: 0.25rem; }
  .pl-8 { padding-left: 2rem; }
  .pr-8 { padding-right: 2rem; }
  .pr-4 { padding-right: 1rem; }
  .pt-10 { padding-top: 2.5rem; }
  .pt-12 { padding-top: 3rem; }
  .mb-1 { margin-bottom: 0.25rem; }
  .mb-2 { margin-bottom: 0.5rem; }
  .mb-4 { margin-bottom: 1rem; }
  .mt-1 { margin-top: 0.25rem; }
  .mt-2 { margin-top: 0.5rem; }
  .mt-4 { margin-top: 1rem; }
  .mt-12 { margin-top: 3rem; }
  .mr-2 { margin-right: 0.5rem; }
  .uppercase { text-transform: uppercase; }
  .w-full { width: 100%; }
  .w-20 { width: 5rem; }
  .w-24 { width: 6rem; }
  .w-32 { width: 8rem; }
  .w-64 { width: 16rem; }
  .w-1\\/2 { width: 50%; }
  .w-3\\/4 { width: 75%; }
  .leading-relaxed { line-height: 1.625; }
  .leading-loose { line-height: 2; }
  .flex { display: flex; }
  .flex-1 { flex: 1 1 0%; }
  .justify-between { justify-content: space-between; }
  .items-start { align-items: flex-start; }
  .items-center { align-items: center; }
  .align-top { vertical-align: top; }
  .text-left { text-align: left; }
  .text-right { text-align: right; }
  table { border-collapse: collapse; }
  @media print {
    body { -webkit-print-color-adjust: exact; print-color-adjust: exact; }
    @page { size: A4 portrait; margin: 15mm; }
  }
`,v=(e,t)=>{let n=window.open(``,`_blank`,`width=900,height=750`);if(!n){alert(`Please allow popups for this site to enable printing.`);return}n.document.open(),n.document.write(`<!DOCTYPE html>
<html>
  <head>
    <title>${t}</title>
    <style>${_}</style>
  </head>
  <body style="background:#ffffff;color:#000000;font-family:Arial,Helvetica,sans-serif;font-size:12px;">
    ${e}
    <script>
      window.onload = function() {
        setTimeout(function() { window.print(); }, 500);
      };
    <\\/script>
  </body>
</html>`),n.document.close()},y=({isOpen:e,onClose:t,data:n})=>{let{showToast:c}=l(),[d,m]=(0,f.useState)(`With Tax`),[h,_]=(0,f.useState)(null),[y,b]=(0,f.useState)(!0),x=(0,f.useRef)(null);(0,f.useEffect)(()=>{(async()=>{if(!(!e||!n)){b(!0);try{let e=await u()||{};_({...n,companyName:e.name||`DEMO COMPANY`,companyAddress:`${e.block||``} ${e.road||``} ${e.building||``} Manama Bahrain`,companyTrn:e.taxRegNo||`N/A`});try{let e=(await s.get(`/Branch/load-backoffice-master-data`)).data,t=(e?.configs||e?.data?.configs||[])[0]||{};t.vatStatus===!0?m(`With Tax`):t.vatStatus===!1&&m(`Without Tax`)}catch(e){console.error(`Failed to fetch backoffice master data for vatStatus:`,e)}}catch(e){console.error(`Failed to fetch company for print:`,e),_({...n,companyName:`DEMO COMPANY`,companyAddress:`Manama, Bahrain`,companyTrn:`N/A`})}finally{b(!1)}}})()},[e,n]);let S=()=>{if(!x.current||!h)return;let e=`${h.docTitle} - ${h.purchaseNo||h.voucherNo||``}`;c(`Opening print dialog — choose "Save as PDF" to export.`,`info`),v(x.current.innerHTML,e)},C=()=>{if(!x.current||!h)return;let e=`${h.docTitle} - ${h.purchaseNo||h.voucherNo||``}`;v(x.current.innerHTML,e)};return e?(0,p.jsxs)(`div`,{className:`fixed inset-0 z-50 flex items-center justify-center p-4`,role:`dialog`,"aria-modal":`true`,children:[(0,p.jsx)(`div`,{className:`absolute inset-0 bg-black/50 backdrop-blur-sm`,onClick:t}),(0,p.jsxs)(`div`,{className:`relative flex flex-col bg-slate-50 rounded-xl shadow-2xl z-10 animate-[fadeIn_0.2s_ease-in-out]`,style:{width:`98vw`,maxWidth:`1400px`,maxHeight:`95vh`},onClick:e=>e.stopPropagation(),children:[(0,p.jsxs)(`div`,{className:`flex items-center justify-between p-4 bg-white border-b rounded-t-xl sticky top-0 z-10 shrink-0`,children:[(0,p.jsx)(`h2`,{className:`text-xl font-bold text-[#49293e]`,children:`Print Preview`}),(0,p.jsxs)(`div`,{className:`flex items-center gap-4`,children:[(0,p.jsxs)(o,{onClick:S,disabled:y,className:`flex items-center gap-2 bg-green-600 hover:bg-green-700`,children:[(0,p.jsx)(a,{size:18}),`Export PDF`]}),(0,p.jsxs)(o,{onClick:C,disabled:y,className:`flex items-center gap-2`,children:[(0,p.jsx)(r,{size:18}),`Print`]}),(0,p.jsx)(`button`,{onClick:t,className:`p-2 hover:bg-slate-100 rounded-full text-slate-500`,children:(0,p.jsx)(i,{size:20})})]})]}),(0,p.jsx)(`div`,{className:`flex-1 overflow-auto p-8 flex justify-center bg-slate-200 rounded-b-xl`,children:y||!h?(0,p.jsx)(`div`,{className:`flex items-center justify-center h-64 text-slate-500 text-sm`,children:`Loading preview...`}):(0,p.jsx)(`div`,{className:`shadow-2xl bg-white`,children:(0,p.jsx)(g,{ref:x,data:h,templateVariant:d})})})]})]}):null};export{y as t};