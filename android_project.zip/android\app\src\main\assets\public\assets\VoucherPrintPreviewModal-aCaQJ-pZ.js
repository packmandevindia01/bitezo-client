const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/html2pdf-DkU-Zyur.js","assets/rolldown-runtime-B1FJdls4.js","assets/html2canvas-Cea2YLRy.js"])))=>i.map(i=>d[i]);
import{i as e}from"./rolldown-runtime-B1FJdls4.js";import{_ as t}from"./vendor-charts-C2P2TtIT.js";import{Hn as n,Mn as r,_t as i,k as a,tn as o}from"./vendor-react-HlPeU5X5.js";import{o as s}from"./ResetButton-UI_PtTYY.js";import{t as c}from"./formatters-BlFhPG4_.js";import{n as l}from"./companyApi-Cvu06Rtn.js";import{r as u}from"./currency-CeNF7eNF.js";var d=e(t(),1),f=r(),p=({data:e})=>{let t=e.voucherType===`RECEIPT`;return(0,f.jsxs)(`div`,{id:`print-template`,className:`w-full bg-white text-black p-8 font-sans mx-auto`,style:{maxWidth:`800px`},children:[(0,f.jsxs)(`div`,{className:`text-center mb-6`,children:[(0,f.jsx)(`div`,{className:`border border-yellow-700 rounded-lg p-2 mb-2`,children:(0,f.jsx)(`h1`,{className:`text-2xl font-bold text-[#49293e]`,style:{color:`#000`},children:e.companyName||`AL ASRIYA ADVANCED TRADING LLC`})}),(0,f.jsx)(`p`,{className:`font-bold text-sm`,children:e.companyAddress||`SULTANATE OF OMAN`}),(0,f.jsxs)(`p`,{className:`font-bold text-sm mt-2`,children:[`Mobile : `,e.companyMobile||`94661313`,` \xA0\xA0\xA0 Phone : `,e.companyPhone||``]})]}),(0,f.jsx)(`div`,{className:`text-center mb-8`,children:(0,f.jsx)(`h2`,{className:`text-xl font-bold underline underline-offset-4`,children:t?`Receipt`:`Payment`})}),(0,f.jsxs)(`div`,{className:`flex justify-between items-end mb-4 font-bold text-sm`,children:[(0,f.jsxs)(`div`,{children:[(0,f.jsxs)(`div`,{className:`flex mb-1`,children:[(0,f.jsx)(`span`,{className:`w-24`,children:`Voucher No`}),(0,f.jsxs)(`span`,{children:[`: \xA0 `,e.voucherNo]})]}),(0,f.jsxs)(`div`,{className:`flex`,children:[(0,f.jsx)(`span`,{className:`w-24`,children:`Date`}),(0,f.jsxs)(`span`,{children:[`: \xA0 `,e.date]})]})]}),(0,f.jsxs)(`div`,{className:`flex`,children:[(0,f.jsx)(`span`,{className:`w-16`,children:`TYPE`}),(0,f.jsxs)(`span`,{children:[`: \xA0 `,e.paymentType||(t?`CASH RECEIPT`:`CASH PAYMENT`)]})]})]}),(0,f.jsxs)(`div`,{className:`border border-dashed border-black p-4 text-sm relative min-h-[160px]`,children:[(0,f.jsxs)(`div`,{className:`flex justify-between mb-4`,children:[(0,f.jsxs)(`div`,{className:`flex flex-1`,children:[(0,f.jsx)(`span`,{className:`w-32`,children:t||e.voucherType===`PAYMENT AGAINST`?`Received from`:`Paid to`}),(0,f.jsxs)(`span`,{className:`flex-1`,children:[`: \xA0 `,e.partyName]})]}),(0,f.jsxs)(`div`,{className:`flex items-center ml-4`,children:[(0,f.jsx)(`span`,{className:`w-20`,children:`Amount`}),(0,f.jsxs)(`span`,{className:`font-bold`,children:[`: \xA0 `,u(),` `,c(e.amount||0)]})]})]}),(0,f.jsxs)(`div`,{className:`flex mb-8`,children:[(0,f.jsx)(`span`,{className:`w-32`,children:`In Words`}),(0,f.jsxs)(`span`,{className:`flex-1`,children:[`: \xA0 `,e.amountInWords]})]}),(0,f.jsxs)(`div`,{className:`flex mb-2`,children:[(0,f.jsx)(`span`,{className:`w-32`,children:`Narration`}),(0,f.jsxs)(`span`,{className:`flex-1`,children:[`: \xA0 `,e.narration||`-`]})]})]}),e.receiptDetails&&e.receiptDetails.length>0&&(0,f.jsxs)(`div`,{className:`mt-8`,children:[(0,f.jsx)(`div`,{className:`text-center mb-2`,children:(0,f.jsx)(`h3`,{className:`font-bold underline underline-offset-4 text-sm uppercase`,children:`Receipt Details`})}),(0,f.jsxs)(`table`,{className:`w-full text-center border-collapse text-sm border border-black`,children:[(0,f.jsx)(`thead`,{children:(0,f.jsxs)(`tr`,{className:`border-b border-black`,children:[(0,f.jsx)(`th`,{className:`border-r border-black py-1`,children:`Sl No`}),(0,f.jsx)(`th`,{className:`border-r border-black py-1`,children:`Vch Type`}),(0,f.jsx)(`th`,{className:`border-r border-black py-1`,children:`Invoice No`}),(0,f.jsx)(`th`,{className:`border-r border-black py-1`,children:`Invoice Date`}),(0,f.jsx)(`th`,{className:`border-r border-black py-1 text-right pr-2`,children:`Invoice Amount`}),(0,f.jsx)(`th`,{className:`py-1 text-right pr-2`,children:`Received Amount`})]})}),(0,f.jsxs)(`tbody`,{children:[e.receiptDetails.map((e,t)=>(0,f.jsxs)(`tr`,{className:`border-b border-black`,children:[(0,f.jsx)(`td`,{className:`border-r border-black py-1`,children:e.sNo}),(0,f.jsx)(`td`,{className:`border-r border-black py-1`,children:e.voucherType}),(0,f.jsx)(`td`,{className:`border-r border-black py-1`,children:e.invoiceNo}),(0,f.jsx)(`td`,{className:`border-r border-black py-1`,children:e.invoiceDate}),(0,f.jsx)(`td`,{className:`border-r border-black py-1 text-right pr-2`,children:c(e.invoiceAmount)}),(0,f.jsx)(`td`,{className:`py-1 text-right pr-2`,children:c(e.receivedAmount)})]},t)),(0,f.jsxs)(`tr`,{className:`border-b border-black`,children:[(0,f.jsx)(`td`,{colSpan:4,className:`border-r border-black py-1`}),(0,f.jsx)(`td`,{className:`border-r border-black py-1 text-right font-bold pr-2`,children:`Total`}),(0,f.jsx)(`td`,{className:`py-1 text-right font-bold pr-2`,children:c(e.amount||0)})]}),(0,f.jsxs)(`tr`,{className:`border-b border-black`,children:[(0,f.jsx)(`td`,{colSpan:4,className:`border-r border-black py-1`}),(0,f.jsx)(`td`,{className:`border-r border-black py-1 text-right font-bold pr-2`,children:`Discount`}),(0,f.jsx)(`td`,{className:`py-1 text-right font-bold pr-2`,children:c(e.discount||0)})]}),(0,f.jsxs)(`tr`,{children:[(0,f.jsx)(`td`,{colSpan:4,className:`border-r border-black py-1`}),(0,f.jsx)(`td`,{className:`border-r border-black py-1 text-right font-bold pr-2`,children:`Net Amount`}),(0,f.jsxs)(`td`,{className:`py-1 text-right font-bold pr-2`,children:[u(),` `,c(e.netAmount??(e.amount||0)-(e.discount||0))]})]})]})]})]})]})},m=`
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body { background: #ffffff; font-family: Arial, Helvetica, sans-serif; font-size: 14px; color: #000000; }
  .p-8 { padding: 2rem; }
  .font-sans { font-family: Arial, Helvetica, sans-serif; }
  .text-center { text-align: center; }
  .font-bold { font-weight: bold; }
  .text-2xl { font-size: 1.5rem; line-height: 2rem; }
  .text-xl { font-size: 1.25rem; line-height: 1.75rem; }
  .text-sm { font-size: 0.875rem; }
  .border { border: 1px solid #000000; }
  .border-dashed { border-style: dashed; }
  .border-yellow-700 { border-color: #854d0e; }
  .rounded-lg { border-radius: 0.5rem; }
  .p-2 { padding: 0.5rem; }
  .p-4 { padding: 1rem; }
  .mb-1 { margin-bottom: 0.25rem; }
  .mb-2 { margin-bottom: 0.5rem; }
  .mb-4 { margin-bottom: 1rem; }
  .mb-6 { margin-bottom: 1.5rem; }
  .mb-8 { margin-bottom: 2rem; }
  .mt-2 { margin-top: 0.5rem; }
  .flex { display: flex; }
  .justify-between { justify-content: space-between; }
  .items-end { align-items: flex-end; }
  .items-center { align-items: center; }
  .flex-1 { flex: 1 1 0%; }
  .w-full { width: 100%; }
  .w-16 { width: 4rem; }
  .w-20 { width: 5rem; }
  .w-24 { width: 6rem; }
  .w-32 { width: 8rem; }
  .underline { text-decoration-line: underline; }
  .underline-offset-4 { text-underline-offset: 4px; }
  .mx-auto { margin-left: auto; margin-right: auto; }
  .relative { position: relative; }
  .min-h-\\[160px\\] { min-height: 160px; }
  .ml-4 { margin-left: 1rem; }
`,h=({isOpen:t,onClose:r,data:c})=>{let[u,h]=(0,d.useState)(c),g=(0,d.useRef)(null);return(0,d.useEffect)(()=>{t&&(async()=>{try{let e=await l();e?.data?h({...c,companyName:e.data.companyName||`AL ASRIYA ADVANCED TRADING LLC`,companyAddress:e.data.buildingNo||`SULTANATE OF OMAN`,companyPhone:e.data.phone||``,companyMobile:e.data.mobile||`94661313`}):h(c)}catch(e){console.error(`Failed to fetch company details for print:`,e),h(c)}})()},[t,c]),t?(0,f.jsx)(`div`,{className:`fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm`,children:(0,f.jsxs)(`div`,{className:`flex flex-col w-full max-w-4xl max-h-[90vh] bg-white rounded-xl shadow-2xl overflow-hidden`,children:[(0,f.jsxs)(`div`,{className:`flex items-center justify-between px-6 py-4 border-b border-gray-200 bg-gray-50 shrink-0`,children:[(0,f.jsxs)(`div`,{children:[(0,f.jsx)(`h2`,{className:`text-lg font-bold text-gray-900`,children:`Print Preview`}),(0,f.jsx)(`p`,{className:`text-xs text-gray-500`,children:`Preview how the voucher will look when printed`})]}),(0,f.jsxs)(`div`,{className:`flex items-center gap-3`,children:[(0,f.jsx)(s,{variant:`secondary`,onClick:async()=>{if(g.current)try{let t=(await n(async()=>{let{default:t}=await import(`./html2pdf-DkU-Zyur.js`).then(t=>e(t.default,1));return{default:t}},__vite__mapDeps([0,1,2]))).default,r=document.createElement(`div`);r.innerHTML=`<style>${m}</style>`+g.current.innerHTML;let i={margin:10,filename:`${u.voucherType}_${u.voucherNo}.pdf`,image:{type:`jpeg`,quality:.98},html2canvas:{scale:2,useCORS:!0,logging:!1},jsPDF:{unit:`mm`,format:`a4`,orientation:`portrait`}};await t().from(r).set(i).save()}catch(e){console.error(`PDF generation failed:`,e)}},icon:(0,f.jsx)(o,{size:16}),children:`PDF`}),(0,f.jsx)(s,{onClick:()=>{if(!g.current)return;let e=g.current.innerHTML,t=window.open(``,`_blank`,`width=800,height=800`);if(!t){alert(`Please allow pop-ups to print.`);return}t.document.write(`
      <!DOCTYPE html>
      <html>
        <head>
          <title>Print ${u.voucherType===`RECEIPT`?`Receipt`:`Payment Voucher`}</title>
          <style>
            @media print {
              @page { margin: 10mm; size: auto; }
            }
            ${m}
          </style>
        </head>
        <body>
          ${e}
        </body>
      </html>
    `),t.document.close(),t.focus(),setTimeout(()=>{t.print(),t.close()},250)},icon:(0,f.jsx)(i,{size:16}),children:`Print`}),(0,f.jsx)(`button`,{onClick:r,className:`p-2 text-gray-400 hover:text-red-500 hover:bg-red-50 rounded-full transition-colors ml-2`,children:(0,f.jsx)(a,{size:20})})]})]}),(0,f.jsx)(`div`,{className:`flex-1 overflow-y-auto p-8 bg-gray-100 flex justify-center`,children:(0,f.jsx)(`div`,{className:`w-full max-w-3xl shadow-lg bg-white`,children:(0,f.jsx)(`div`,{ref:g,children:(0,f.jsx)(p,{data:u})})})})]})}):null};export{h as t};