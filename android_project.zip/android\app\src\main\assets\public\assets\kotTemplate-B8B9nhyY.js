var e=(e,t)=>{let n=new Date,r=t.date||n.toLocaleDateString(`en-GB`),i=t.time||n.toLocaleTimeString(`en-US`),a=(t.orderType||`DINE IN`).toUpperCase(),o=``;e.forEach(e=>{let t=(e.product?.name||`Item #${e.productId}`).toUpperCase();e.variantName&&e.variantName.toLowerCase().trim()!==`main`&&(t+=` - ${e.variantName.toUpperCase()}`);let n=e.quantity,r=0;e.extras&&e.extras.length>0&&e.extras.forEach(e=>r+=e.price*(e.qty||1));let i=e.lineTotal;i===void 0?i=(e.price||e.product?.price||0)*e.quantity:i-=r;let a=i.toFixed(3);o+=`
      <tr>
        <td style="width: 15%; text-align: left; vertical-align: top; font-weight: bold;">${n}</td>
        <td style="width: 60%; text-align: left; vertical-align: top; font-weight: bold;">${t}</td>
        <td style="width: 25%; text-align: right; vertical-align: top; font-weight: bold;">${a}</td>
      </tr>
    `,e.extras&&e.extras.length>0&&e.extras.forEach(e=>{let t=(e.name||`EXTRA`).toUpperCase(),n=(e.price*e.qty).toFixed(3);o+=`
          <tr>
            <td style="text-align: left; vertical-align: top;"></td>
            <td style="text-align: left; vertical-align: top; padding-left: 10px;">+ ${t}</td>
            <td style="text-align: right; vertical-align: top; font-weight: bold;">${n}</td>
          </tr>
        `}),e.modifiers&&e.modifiers.length>0&&e.modifiers.forEach(e=>{let t=(e.name||`MODIFIER`).toUpperCase();o+=`
          <tr>
            <td style="text-align: left; vertical-align: top;"></td>
            <td style="text-align: left; vertical-align: top; padding-left: 10px; font-style: italic;">* ${t}</td>
            <td style="text-align: right; vertical-align: top;"></td>
          </tr>
        `})});let s=`
      <head>
        <style>
          body {
            font-family: Arial, Helvetica, sans-serif;
            font-size: 13px;
            color: #000;
            margin: 0;
            padding: 0;
            width: 100%;
          }
          .text-center { text-align: center; }
          .font-bold { font-weight: bold; }
          
          table.meta-table {
            width: 100%;
            margin-bottom: 15px;
            font-size: 14px;
            font-weight: bold;
          }
          table.meta-table td {
            padding-bottom: 3px;
          }
          
          hr {
            border: none;
            border-top: 2px solid #000;
            margin: 5px 0;
          }

          table.items-table {
            width: 100%;
            border-collapse: collapse;
            font-size: 14px;
            margin-top: 10px;
          }
          
          table.items-table th {
            text-align: left;
            font-weight: bold;
            text-transform: uppercase;
            padding-bottom: 5px;
          }
          table.items-table td {
            padding: 2px 0;
          }
        </style>
      </head>
  `;return t.isMaster?`
      <html>
        ${s}
        <body>
          <table style="width: 100%; font-size: 22px; font-weight: bold; margin-bottom: 15px;">
            <tr>
              <td style="text-align: left;">Order &nbsp; #${t.orderNo}</td>
              <td style="text-align: right;">${a}</td>
            </tr>
          </table>
          
          <table class="meta-table">
            <tr>
              <td style="width: 50%;">Date : <span style="font-weight: normal">${r}</span></td>
              <td style="width: 50%;">Time : <span style="font-weight: normal">${i}</span></td>
            </tr>
            <tr>
              <td>Waiter : <span style="font-weight: normal">${t.waiter}</span></td>
              <td>Terminal : <span style="font-weight: normal">${t.counter}</span></td>
            </tr>
            <tr>
              <td></td>
              <td>Section : <span style="font-weight: normal">${t.section}</span></td>
            </tr>
          </table>
          
          <div class="text-center" style="font-size: 24px; font-weight: bold; margin: 15px 0;">Table : ${t.table}</div>
          
          <hr />
          <div class="text-center" style="font-size: 24px; font-weight: bold; margin: 10px 0;">***${t.headerTitle||`KOT`}***</div>
          <hr />
          
          <table class="items-table">
            <thead>
              <tr>
                <th style="width: 15%;">QTY</th>
                <th style="width: 60%;">DESCRIPTION</th>
                <th style="width: 25%; text-align: right;">AMT</th>
              </tr>
            </thead>
            <tbody>
              <tr><td colspan="3"><hr style="border-top: 1px solid #000; margin: 2px 0 8px 0;" /></td></tr>
              ${o}
            </tbody>
          </table>
          
          <div class="text-center" style="font-size: 24px; font-weight: bold; margin-top: 30px;">Ticket No #${t.ticketNo}</div>
          <div class="text-center" style="font-size: 12px; margin-top: 5px;">Print On : ${r} ${i}</div>
        </body>
      </html>
    `:`
    <html>
      ${s}
      <body>
        <div class="text-center" style="font-size: 22px; font-weight: bold; margin-bottom: 10px;">${a}</div>
        <div class="text-center" style="font-size: 24px; font-weight: bold; margin-bottom: 15px; letter-spacing: 1px;">***${t.headerTitle||`KOT`}***</div>
        
        <table class="meta-table">
          <tr>
            <td style="width: 50%;">Date &nbsp;&nbsp;&nbsp; <span style="font-weight: normal">${r}</span></td>
            <td style="width: 50%;">Time &nbsp;&nbsp;&nbsp; <span style="font-weight: normal">${i}</span></td>
          </tr>
          <tr>
            <td>Waiter : <span style="font-weight: normal">${t.waiter}</span></td>
            <td>Counter : <span style="font-weight: normal">${t.counter}</span></td>
          </tr>
          <tr>
            <td>Section : <span style="font-weight: normal">${t.section}</span></td>
            <td>Table : <span style="font-weight: normal">${t.table}</span></td>
          </tr>
        </table>
        
        <table style="width: 100%; margin-top: 15px; font-size: 16px;">
          <tr>
            <td style="width: 50%; text-align: left;">Order No &nbsp; <span style="font-size: 22px; font-weight: bold;">#${t.orderNo}</span></td>
            <td style="width: 50%; text-align: right;">Ticket No &nbsp; <span style="font-size: 22px; font-weight: bold;">#${t.ticketNo}</span></td>
          </tr>
        </table>
        
        <hr />
        
        <table class="items-table">
          <thead>
            <tr>
              <th style="width: 15%;">QTY</th>
              <th style="width: 60%;">DESCRIPTION</th>
              <th style="width: 25%; text-align: right;">AMT</th>
            </tr>
          </thead>
          <tbody>
            <tr><td colspan="3"><hr style="border-top: 1px solid #000; margin: 2px 0 8px 0;" /></td></tr>
            ${o}
          </tbody>
        </table>
      </body>
    </html>
  `};export{e as generateKotHtml};