import{n as e}from"./rolldown-runtime-B1FJdls4.js";var t=e({generateGuestPrintHtml:()=>n}),n=(e,t)=>{let n=new Date,r=t.date||n.toLocaleDateString(`en-GB`),i=t.time||n.toLocaleTimeString(`en-US`),a=t.orderType?.toLowerCase().includes(`take`),o=t.orderType?.toLowerCase().includes(`drive`),s=t.orderType?.toLowerCase().includes(`dine`),c=t.orderType?.toLowerCase().includes(`delivery`),l=t.isSettlement?``:`GUEST`;a?l=t.isSettlement?`(TAKE OUT)`:`GUEST (TAKE OUT)`:o?l=t.isSettlement?`(DRIVE THRU)`:`GUEST (DRIVE THRU)`:s?l=t.isSettlement?`(DINE IN)`:`GUEST (DINE IN)`:c&&(l=t.isSettlement?`(DELIVERY)`:`GUEST (DELIVERY)`);let u=t.enableVat?`SIMPLIFIED TAX INVOICE<br/>${l}`:`SIMPLIFIED INVOICE<br/>${l}`,d=``;return e.forEach(e=>{let t=(e.product?.name||`Item #${e.productId}`).toUpperCase();e.variantName&&e.variantName.toLowerCase().trim()!==`main`&&(t+=` - ${e.variantName.toUpperCase()}`);let n=e.quantity,r=0;e.extras&&e.extras.length>0&&e.extras.forEach(e=>r+=e.price*(e.qty||1));let i=e.lineTotal;i===void 0?i=(e.price||e.product?.price||0)*e.quantity:i-=r;let a=(i/n).toFixed(3),o=i.toFixed(3);d+=`
      <tr>
        <td style="width: 10%; text-align: left; vertical-align: top; padding: 2px 0;">${n}</td>
        <td style="width: 45%; text-align: left; vertical-align: top; padding: 2px 0;">${t}</td>
        <td style="width: 20%; text-align: right; vertical-align: top; padding: 2px 0;">${a}</td>
        <td style="width: 25%; text-align: right; vertical-align: top; padding: 2px 0;">${o}</td>
      </tr>
    `,e.extras&&e.extras.length>0&&e.extras.forEach(e=>{let t=(e.name||`EXTRA`).toUpperCase(),n=e.price.toFixed(3),r=(e.price*(e.qty||1)).toFixed(3);d+=`
          <tr>
            <td style="text-align: left; vertical-align: top; padding: 2px 0;">${e.qty||1}</td>
            <td style="text-align: left; vertical-align: top; padding: 2px 0;">${t}</td>
            <td style="text-align: right; vertical-align: top; padding: 2px 0;">${n}</td>
            <td style="text-align: right; vertical-align: top; padding: 2px 0;">${r}</td>
          </tr>
        `}),e.modifiers&&e.modifiers.length>0&&e.modifiers.forEach(e=>{let t=(e.name||`MODIFIER`).toUpperCase();d+=`
          <tr>
            <td style="text-align: left; vertical-align: top;"></td>
            <td style="text-align: left; vertical-align: top; font-style: italic;">* ${t}</td>
            <td style="text-align: right; vertical-align: top;"></td>
            <td style="text-align: right; vertical-align: top;"></td>
          </tr>
        `})}),`
    <html>
      <head>
        <style>
          body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            font-size: 13px;
            color: #000;
            margin: 0;
            padding: 0;
            width: 100%;
          }
          .text-center { text-align: center; }
          .font-bold { font-weight: bold; }
          .header-title { font-size: 18px; margin-bottom: 15px; letter-spacing: 1px; }
          
          table { width: 100%; border-collapse: collapse; font-size: 13px; }
          
          .dashed-hr { border: none; border-top: 1px dashed #000; margin: 8px 0; }
          .solid-hr { border: none; border-top: 1px solid #000; margin: 5px 0; }
          
          table.items-table th {
            text-align: left;
            font-weight: bold;
            text-transform: capitalize;
            padding-bottom: 5px;
          }

          .meta-row { display: flex; justify-content: space-between; margin-bottom: 2px; font-weight: bold;}
          
          .totals-table { margin-top: 5px; font-size: 13px; }
          .totals-table td { padding: 2px 0; }
          .totals-label { text-align: left; }
          .totals-value { text-align: right; }
          
          .grand-total { font-size: 18px; font-weight: bold; }

          .vat-table { margin-top: 8px; font-weight: bold; font-size: 12px; }
          .vat-table th { text-align: left; padding-bottom: 5px; }
          .vat-table td { padding: 3px 0; }
          
          .barcode-container { text-align: center; margin-top: 15px; margin-bottom: 5px; font-family: 'Libre Barcode 39', 'Courier New', Courier, monospace; font-size: 40px;}
        </style>
      </head>
      <body>
        <div class="text-center font-bold" style="font-size: 16px;">GOLD RESTAURANT</div>
        <div class="text-center" style="margin-bottom: 10px;">
          <div>Tea World</div>
          <div>Building:65,Road:2003,Block:320</div>
          <div>HOORA</div>
          <div>CR NO:48622-16</div>
          ${t.enableVat?`<div>VAT NO:220003229000002</div>`:``}
          <div>Tel:17311999,Tel:17311999</div>
        </div>

        <div class="text-center header-title">${u}</div>
        
        <div class="dashed-hr" style="border-top: 1px solid #000;"></div>

        <div class="meta-row">
          <div style="width: 50%;">Order No &nbsp; <span style="font-size: 16px; font-weight: bold;">#${t.orderNo}</span></div>
          <div style="width: 50%;">Ticket No &nbsp; <span style="font-size: 16px; font-weight: bold;">#${t.ticketNo}</span></div>
        </div>
        <div class="meta-row">
          <div style="width: 50%;">Date &nbsp; <span style="font-weight: normal">${r}</span></div>
          <div style="width: 50%;">Time &nbsp; <span style="font-weight: normal">${i}</span></div>
        </div>
        <div class="meta-row">
          <div style="width: 50%;">Employee &nbsp; <span style="font-weight: normal">${t.waiter}</span></div>
          <div style="width: 50%;">Counter &nbsp; <span style="font-weight: normal">${t.counter}</span></div>
        </div>
        ${s?`
        <div class="meta-row">
          <div style="width: 50%;">Section &nbsp; <span style="font-weight: normal">${t.section}</span></div>
          <div style="width: 50%;">Table &nbsp; <span style="font-weight: normal">${t.table}</span></div>
        </div>
        `:``}
        
        <div class="dashed-hr"></div>
        
        <table class="items-table">
          <thead>
            <tr>
              <th style="width: 10%;">SNo</th>
              <th style="width: 45%;">Description</th>
              <th style="width: 20%; text-align: right;">Rate</th>
              <th style="width: 25%; text-align: right;">Amt</th>
            </tr>
          </thead>
          <tbody>
            <tr><td colspan="4"><div class="dashed-hr" style="margin: 2px 0 8px 0;"></div></td></tr>
            ${d}
          </tbody>
        </table>
        
        <div class="dashed-hr"></div>

        <table class="totals-table">
          <tr>
            <td class="totals-label">Sub Total</td>
            <td class="totals-value">${t.subTotal.toFixed(3)}</td>
          </tr>
          ${t.serviceCharge>0?`
          <tr>
            <td class="totals-label">Service Charge</td>
            <td class="totals-value">${t.serviceCharge.toFixed(3)}</td>
          </tr>
          `:``}
          ${t.levy>0?`
          <tr>
            <td class="totals-label">Levy(5%)</td>
            <td class="totals-value">${t.levy.toFixed(3)}</td>
          </tr>
          `:``}
          ${c||t.deliveryCharge&&t.deliveryCharge>0?`
          <tr>
            <td class="totals-label">Delivery Charge</td>
            <td class="totals-value">${(t.deliveryCharge||0).toFixed(3)}</td>
          </tr>
          `:``}
          ${t.enableVat?`
          <tr>
            <td class="totals-label">VAT Amount</td>
            <td class="totals-value">${t.vatAmount.toFixed(3)}</td>
          </tr>
          `:``}
          <tr>
            <td class="totals-label grand-total">Grand Total</td>
            <td class="totals-value grand-total">${t.netAmount.toFixed(3)}</td>
          </tr>
          ${t.payments&&t.payments.length>0?`
          <tr><td colspan="2"><div class="dashed-hr" style="margin: 5px 0;"></div></td></tr>
          ${t.payments.map(e=>`
          <tr>
            <td class="totals-label">${e.name}</td>
            <td class="totals-value">${e.amount.toFixed(3)}</td>
          </tr>
          `).join(``)}
          `:``}
          ${t.changeAmount!==void 0&&t.changeAmount>0?`
          <tr>
            <td class="totals-label font-bold">Change</td>
            <td class="totals-value font-bold">${t.changeAmount.toFixed(3)}</td>
          </tr>
          `:``}
        </table>

        ${t.enableVat?`
        <div class="dashed-hr"></div>
        <table class="vat-table">
          <thead>
            <tr>
              <th>VAT Code</th>
              <th>Excl Amt</th>
              <th>VAT Amt</th>
              <th>Net Amt</th>
            </tr>
          </thead>
          <tbody>
            <tr><td colspan="4"><div class="dashed-hr" style="margin: 0px 0 6px 0;"></div></td></tr>
            <tr>
              <td style="font-weight: normal;">10%</td>
              <td style="font-weight: normal;">${(t.netAmount-t.vatAmount).toFixed(3)}</td>
              <td style="font-weight: normal;">${t.vatAmount.toFixed(3)}</td>
              <td style="font-weight: normal;">${t.netAmount.toFixed(3)}</td>
            </tr>
            <tr><td colspan="4"><div class="dashed-hr" style="margin: 6px 0 0px 0;"></div></td></tr>
          </tbody>
        </table>
        `:`<div class="dashed-hr"></div>`}
        
        ${(o||c)&&(t.vehicleNo||t.customerName||t.contactNo||t.flatNo||t.buildingNo||t.blockNo||t.roadNo||t.area||t.providerNo)?`
        <div style="margin-top: 10px; font-size: 12px;">
          <div style="font-weight: bold; text-transform: uppercase; margin-bottom: 3px;">${c?`DELIVERY DETAILS`:`CUSTOMER DETAILS`}</div>
          <div class="solid-hr" style="border-top: 1px solid #000; margin-bottom: 5px;"></div>
          <table style="width: 100%; font-size: 12px; margin-top: 5px;">
            ${t.contactNo?`<tr><td style="width: 35%; padding-bottom: 2px;">Mob No</td><td style="font-weight: bold;">${t.contactNo}</td></tr>`:``}
            ${t.customerName?`<tr><td style="width: 35%; padding-bottom: 2px;">Customer</td><td style="font-weight: bold;">${t.customerName}</td></tr>`:``}
            ${t.flatNo?`<tr><td style="width: 35%; padding-bottom: 2px;">Flat No</td><td style="font-weight: bold;">${t.flatNo}</td></tr>`:``}
            ${t.buildingNo?`<tr><td style="width: 35%; padding-bottom: 2px;">Building</td><td style="font-weight: bold;">${t.buildingNo}</td></tr>`:``}
            ${t.blockNo?`<tr><td style="width: 35%; padding-bottom: 2px;">Block</td><td style="font-weight: bold;">${t.blockNo}</td></tr>`:``}
            ${t.roadNo?`<tr><td style="width: 35%; padding-bottom: 2px;">Road</td><td style="font-weight: bold;">${t.roadNo}</td></tr>`:``}
            ${t.area?`<tr><td style="width: 35%; padding-bottom: 2px;">Area</td><td style="font-weight: bold;">${t.area}</td></tr>`:``}
            ${t.vehicleNo?`<tr><td style="width: 35%; padding-bottom: 2px;">Vehicle No</td><td style="font-weight: bold;">${t.vehicleNo}</td></tr>`:``}
            ${t.providerNo?`<tr><td style="width: 35%; padding-bottom: 2px;">Provider No</td><td style="font-weight: bold;">${t.providerNo}</td></tr>`:``}
          </table>
        </div>
        `:``}

        <div class="barcode-container">*${t.orderNo}*</div>
        
        <div style="font-size: 11px; margin-top: 5px;">Print Time : ${r} ${i}</div>
      </body>
    </html>
  `};export{t as n,n as t};